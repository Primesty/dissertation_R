

#' Correlation significance
#'
#' This function tests the significance of correlations
#' @param mat A correlation matrix.
#' @param conf.level The confidence level.
#' @keywords correlation significance
#' @export
#' @examples
#' cor_mtest(mat, conf.level = 0.95)

cor_mtest <- function(mat, conf.level = 0.95){
        mat <- as.matrix(mat)
        n <- ncol(mat)
        p.mat <- lowCI.mat <- uppCI.mat <- matrix(NA, n, n)
        diag(p.mat) <- 0
        diag(lowCI.mat) <- diag(uppCI.mat) <- 1
        for(i in 1:(n-1)){
                for(j in (i+1):n){
                        tmp <- cor.test(mat[,i], mat[,j], conf.level = conf.level)
                        p.mat[i,j] <- p.mat[j,i] <- tmp$p.value
                        lowCI.mat[i,j] <- lowCI.mat[j,i] <- tmp$conf.int[1]
                        uppCI.mat[i,j] <- uppCI.mat[j,i] <- tmp$conf.int[2]
                }
        }
        return(list(p.mat, lowCI.mat, uppCI.mat))
}